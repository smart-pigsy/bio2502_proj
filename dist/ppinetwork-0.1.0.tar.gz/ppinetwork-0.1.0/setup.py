from setuptools import setup, find_packages
import codecs

# 确保以UTF-8编码读取所有文件
def read_file(filename):
    with codecs.open(filename, 'r', 'utf-8') as f:
        return f.read()

setup(
    name="ppinetwork",
    version="0.1.0",
    author="你的名字",
    author_email="your.email@example.com",
    description="一个用于分析蛋白质相互作用网络的Python包",
    long_description=read_file("README.md"),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/ppinetwork",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[
        "pandas",
        "networkx",
        "matplotlib",
    ],
)
