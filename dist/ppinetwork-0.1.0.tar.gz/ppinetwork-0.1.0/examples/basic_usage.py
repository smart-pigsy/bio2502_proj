"""
这是一个使用 ppinetwork 包的示例脚本
展示了如何加载数据、分析网络结构和计算最短路径
"""

from ppinetwork import PPINetwork

def main():    # 初始化并加载数据
    import os
    package_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    test_data_path = os.path.join(package_root, "test_data.txt")
    ppi_network = PPINetwork(
        file_path=test_data_path,
        min_score=400,
        weight_type="inverse"
    )
    
    # 分析网络结构
    print("分析网络结构...")
    stats = ppi_network.analyze_graph()
      # 设置源节点和目标节点
    source_node = "A"  # 起始蛋白质
    target_node = "D"  # 目标蛋白质
    
    # 使用不同的算法计算最短路径
    
    print("\n使用Dijkstra算法:")
    dijkstra = ppi_network.run_dijkstra(source_node)
    path = dijkstra.get_shortest_path(target_node)
    distance = dijkstra.distances[target_node]
    print(f"从 {source_node} 到 {target_node} 的最短路径:")
    print(f"路径: {' → '.join(path)}")
    print(f"距离: {distance:.4f}")
    
    print("\n使用并行Dijkstra算法:")
    all_distances, node_list = ppi_network.run_parallel_dijkstra_adjlist(num_processes=4)
    
    # 可视化网络
    print("\n生成网络可视化...")
    ppi_network.visualize(
        max_nodes=100,
        output_file="network_visualization.png"
    )
    
    # 导出可视化数据
    print("\n导出可视化数据...")
    ppi_network.export_for_visualization(
        output_file="ppi_visualization.graphml",
        source=source_node,
        target=target_node,
        highlight_path=True,
        highlight_central=True,
        centrality_threshold=0.85
    )

if __name__ == "__main__":
    main()
