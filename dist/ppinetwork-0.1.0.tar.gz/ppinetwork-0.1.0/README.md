# PPI Network Analysis Package

A Python package for protein-protein interaction (PPI) network construction, analysis, and shortest path computation.

## 目录结构

```
ppinetwork/
    __init__.py
    bellman_ford.py
    dijkstra.py
    floyd_warshall.py
    spfa.py
    paralleldijkstra.py
    main.py
    demo.py
    manual.md
    test_data/
        7209.protein.physical.links.v12.0.txt
```

## 主要功能
- 支持PPI网络的构建与分析
- 集成Bellman-Ford、Dijkstra、SPFA、Floyd-Warshall等最短路径算法
- 支持并行Dijkstra全对最短路径
- 支持网络可视化、GraphML导出、中心性分析

## 安装依赖
```
pip install pandas networkx matplotlib numpy
```

## 使用示例
见 demo.py

## 详细说明
见 manual.md
